"use strict";
const nodemailer = require("nodemailer");


////////////////////////////////// SECURE MAIL ///////////////////////////////////////
async function Mail(MailBody, MailSubject){
  var smtpTransport = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: '465',
      secure: 'true',
      auth:{
          type:'Oauth2',
          user: 'kordsabot.project.01@gmail.com',
          clientId: "2264639882-i19u9ima6ened2nakfqqpjrm3cnab6of.apps.googleusercontent.com",
          clientSecret: "hJzCeUoueheERJt8eI3b4KUk",
          refreshToken: "1/ZxmSMu4vgRv9tCNX25Xl3pLHHt28vZz0jP6CqJUAS6E",
      }
  });
  var messageTemplate = {
      from: '"Jojo" <kordsabot.project.01@gmail.com>',
      to: 'aziz.baybur@kordsa.com',
      subject: MailSubject,
      text: MailBody,
      //html: req.body.content + '<\br>' + '<b>' +'This is html' + '<\b>',
  };
  try{
      // send mail with defined transport object
      //let info = await smtpTransport.sendMail(messageTemplate);
      (async () => {
        await smtpTransport.sendMail(messageTemplate);
        smtpTransport.close();
        return true;
        //return await info.messageId;
      })()
      }
      catch (err) {
        smtpTransport.close();
        return err.message;
      }
    }
////////////////////////////////// NON SECURE MAIL /////////////////////////////////////
async function Mail_Old(MailBody, MailSubject){

  // Generate test SMTP service account from ethereal.email
  // let account = await nodemailer.createTestAccount();

  // Create reusable transporter object using the default SMTP transport
  let transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 465,
    secure: true,
    //service:"Gmail",
    auth: {
      user: 'kordsabot.project.01@gmail.com', 
      pass: 'uK425CEaekJrm4b'
    }
  });

  // setup email data with unicode symbols
  let mailOptions = {
    from: '"Jojo" <kordsabot.project.01@gmail.com>', 
    to: 'aziz.baybur@kordsa.com', 
    subject: MailSubject, 
    text: MailBody
    //html: "<b>Jojo World</b>"
  };
  try {
    // send mail with defined transport object
    let info = await transporter.sendMail(mailOptions)
    return await info.messageId; 
    }
    catch (err) {
        return err.message;
    }
  // console.log("Message sent: %s", info.messageId);
  // console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
}

const express = require('express');
const router = express.Router();
const nodeMailer = require('nodemailer');
//var clientSecret = require('../client_secret');