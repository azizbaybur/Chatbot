console.log(new Date().getHours());
console.log(new Date().getMinutes());
