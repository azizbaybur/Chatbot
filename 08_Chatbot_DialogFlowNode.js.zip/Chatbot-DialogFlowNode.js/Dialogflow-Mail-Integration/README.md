# dialog-flow-mail-sample - Mail From Dialog Flow

This simple app will help you understand
- How to send mail through Dialog Flow

# Deploy to:
[![Deploy to Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)